import React from 'react';
import { cn } from '../lib/utils';

interface DecorativeBarProps {
  className?: string;
  variant?: 'left' | 'right' | 'center';
}

export function DecorativeBar({ className, variant = 'center' }: DecorativeBarProps) {
  return (
    <div className={cn(
      'relative h-1 bg-gradient-to-r from-transparent via-purple-300/50 to-transparent',
      variant === 'left' && 'from-purple-500 via-purple-300/50 to-transparent',
      variant === 'right' && 'from-transparent via-purple-300/50 to-purple-500',
      className
    )}>
      <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 via-purple-300/30 to-purple-500/20 animate-gradient" />
    </div>
  );
}