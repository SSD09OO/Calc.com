import React, { useState } from 'react';
import { Youtube, Sparkles } from 'lucide-react';
import { Toaster, toast } from 'react-hot-toast';
import { ThumbnailForm } from './components/ThumbnailForm';
import { ThumbnailGrid } from './components/ThumbnailGrid';
import { DecorativeBar } from './components/DecorativeBar';
import { LanguageSwitch } from './components/LanguageSwitch';
import { useLanguage } from './contexts/LanguageContext';

const DEMO_THUMBNAILS = [
  'https://images.unsplash.com/photo-1611162617474-5b21e879e113',
  'https://images.unsplash.com/photo-1626814026160-2237a95fc5a0',
  'https://images.unsplash.com/photo-1492619375914-88005aa9e8fb',
];

export default function App() {
  const { t } = useLanguage();
  const [thumbnails, setThumbnails] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async (prompt: string, videoUrl: string | null) => {
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setThumbnails(DEMO_THUMBNAILS);
    setLoading(false);
  };

  const handleRegenerate = () => {
    toast.promise(
      handleGenerate('', null),
      {
        loading: t('toasts.loading'),
        success: t('toasts.success'),
        error: t('toasts.error'),
      }
    );
  };

  const handleSelect = (index: number) => {
    toast.success(t('toasts.selected'));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-gray-100">
      <DecorativeBar className="fixed top-0 left-0 right-0 z-50" />
      <LanguageSwitch />
      
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center mb-16 relative">
          <div className="absolute inset-0 -z-10">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 via-purple-300/20 to-purple-500/10 animate-gradient" />
          </div>
          
          <div className="inline-flex items-center justify-center gap-3 px-6 py-2 rounded-full bg-white/30 backdrop-blur-sm border border-white/20 shadow-xl mb-8 animate-float">
            <Youtube className="h-6 w-6 text-purple-600" />
            <h1 className="text-4xl font-extrabold tracking-wider bg-gradient-to-r from-purple-600 to-purple-500 bg-clip-text text-transparent">
              {t('title')}
            </h1>
          </div>
          
          <p className="text-gray-600 max-w-2xl mx-auto text-lg leading-relaxed font-medium">
            {t('description')}
          </p>
        </div>

        <div className="space-y-16">
          <div className="glass-card rounded-2xl p-8 max-w-3xl mx-auto relative overflow-hidden">
            <DecorativeBar className="absolute -top-0.5 left-0 right-0" variant="left" />
            <DecorativeBar className="absolute -bottom-0.5 left-0 right-0" variant="right" />
            
            <div className="flex items-center gap-2 mb-6">
              <Sparkles className="h-5 w-5 text-purple-500" />
              <h2 className="text-xl font-bold text-gray-800">
                {t('startCreating')}
              </h2>
            </div>
            <ThumbnailForm onGenerate={handleGenerate} />
          </div>

          {(thumbnails.length > 0 || loading) && (
            <div className="glass-card rounded-2xl p-8 relative overflow-hidden">
              <DecorativeBar className="absolute -top-0.5 left-0 right-0" variant="right" />
              <DecorativeBar className="absolute -bottom-0.5 left-0 right-0" variant="left" />
              
              <ThumbnailGrid
                thumbnails={thumbnails}
                onRegenerate={handleRegenerate}
                onSelect={handleSelect}
                loading={loading}
              />
            </div>
          )}
        </div>
      </div>
      
      <DecorativeBar className="fixed bottom-0 left-0 right-0 z-50" />
      
      <Toaster 
        position="bottom-right"
        toastOptions={{
          className: 'glass-card',
          duration: 3000,
        }}
      />
    </div>
  );
}