export type Language = 'fr' | 'en';

export const translations = {
  fr: {
    title: 'GEN',
    description: 'Créez des miniatures YouTube captivantes en quelques clics. Notre IA analyse votre contenu pour générer des visuels uniques et engageants.',
    startCreating: 'Commencez votre création',
    promptLabel: 'Description de la vidéo',
    promptPlaceholder: 'Décrivez votre vidéo pour générer une miniature adaptée...',
    or: 'OU',
    urlLabel: 'URL YouTube',
    urlPlaceholder: 'https://youtube.com/watch?v=...',
    generateButton: 'Générer les miniatures',
    regenerateButton: 'Régénérer les miniatures',
    version: 'Version',
    loading: 'Génération des miniatures...',
    errors: {
      emptyFields: 'Veuillez fournir soit une description, soit une URL YouTube',
      invalidUrl: 'URL YouTube invalide'
    },
    toasts: {
      loading: 'Génération en cours...',
      success: 'Nouvelles miniatures générées !',
      error: 'Erreur lors de la génération',
      selected: 'Miniature sélectionnée ! Vous pouvez la télécharger.'
    }
  },
  en: {
    title: 'GEN',
    description: 'Create engaging YouTube thumbnails with just a few clicks. Our AI analyzes your content to generate unique and captivating visuals.',
    startCreating: 'Start Creating',
    promptLabel: 'Video Description',
    promptPlaceholder: 'Describe your video to generate a suitable thumbnail...',
    or: 'OR',
    urlLabel: 'YouTube URL',
    urlPlaceholder: 'https://youtube.com/watch?v=...',
    generateButton: 'Generate Thumbnails',
    regenerateButton: 'Regenerate Thumbnails',
    version: 'Version',
    loading: 'Generating thumbnails...',
    errors: {
      emptyFields: 'Please provide either a description or a YouTube URL',
      invalidUrl: 'Invalid YouTube URL'
    },
    toasts: {
      loading: 'Generating...',
      success: 'New thumbnails generated!',
      error: 'Generation failed',
      selected: 'Thumbnail selected! You can now download it.'
    }
  }
} as const;